---
title: 欢迎回家！
layout: home
hero:
  name: 服务器集体宣传组织</br>欢迎回家！
  tagline: 愿您宣传一生，归来仍是集宣！
  image:
    src: /logo.png
    alt: 服务器集体宣传组织
  actions:
    - theme: brand
      text: 回到集宣！
      link: https://go.flweb.cn/mcjpg
    # - theme: alt
      # text: View on GitHub
      # link: https://github.com/vuejs/vitepress
features:
---
